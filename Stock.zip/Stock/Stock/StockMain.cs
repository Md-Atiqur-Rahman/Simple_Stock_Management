﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stock
{
    public partial class StockMain : Form
    {
        

        public StockMain()
        {
            InitializeComponent();
        }

        private void productsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Products pro = new Products();
            pro.MdiParent = this;//only show oneicon  if u see the task bar and product window will be shown under the stock window,
            pro.Show();
        }
        bool close = true;//it is used for closing your window in one time .
        private void StockMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            //when this window is closed it will be closed from program..
            if (close)
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure want to Exit", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogResult == DialogResult.Yes)
                {
                    close = false;
                    Application.Exit();
                }
                else
                {
                    e.Cancel = true;
                }
            }
        }

        private void stockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Stock stk = new Stock();
            stk.MdiParent = this;//only show oneicon  if u see the task bar and product window will be shown under the stock window,
            stk.StartPosition = FormStartPosition.CenterScreen;
            stk.Show();
        }

        private void productsListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepotForm.ProductsReport prod = new RepotForm.ProductsReport();
            prod.MdiParent = this;//only show oneicon  if u see the task bar and product window will be shown under the stock window,
            prod.StartPosition = FormStartPosition.CenterScreen;
            prod.Show();
        }

        private void stockListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepotForm.StockReport prod = new RepotForm.StockReport();
            prod.MdiParent = this;//only show oneicon  if u see the task bar and product window will be shown under the stock window,
            prod.StartPosition = FormStartPosition.CenterScreen;
            prod.Show();
        }

    }
}
